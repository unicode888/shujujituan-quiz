#!/bin/bash
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1 && python3 -c 'from http.server import ThreadingHTTPServer' >/dev/null 2>&1; then
  python3 "组件/lan.py" "$@"
elif command -v node >/dev/null 2>&1; then
  node "组件/lan.cjs" "$@"
else
  echo '手机局域网模式需要 Python 3.7+ 或 Node.js 16+。电脑可直接双击「综合刷题.html」。'
fi
code=$?
if [ -t 0 ]; then read -r -p '按回车关闭窗口。'; fi
exit "$code"
