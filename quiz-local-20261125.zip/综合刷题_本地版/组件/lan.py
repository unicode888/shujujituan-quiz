"""Read-only local server for the packaged quiz. Python 3 standard library only."""
import argparse
import functools
import ipaddress
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

HERE = Path(__file__).resolve().parent
FILES = {
    "/": ("../综合刷题.html", "text/html; charset=utf-8"),
    "/index.html": ("../综合刷题.html", "text/html; charset=utf-8"),
    "/mobile.html": ("../综合刷题.html", "text/html; charset=utf-8"),
    "/connect": ("connect.html", "text/html; charset=utf-8"),
    "/qr.js": ("qrcode.js", "text/javascript; charset=utf-8"),
    "/icon.png": ("icon.png", "image/png"),
    "/manifest.webmanifest": ("manifest.webmanifest", "application/manifest+json"),
}
def addresses():
    candidates = []
    if sys.platform == "darwin":
        for interface in ("en0", "en1", "en2"):
            p = subprocess.run(["/usr/sbin/ipconfig", "getifaddr", interface], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            candidates.append(p.stdout.decode().strip())
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("192.0.2.1", 9))  # Inspect the local default route. No payload is sent.
            candidates.append(probe.getsockname()[0])
    except OSError:
        pass
    try:
        candidates.extend(row[4][0] for row in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET))
    except OSError:
        pass
    found = []
    for value in candidates:
        try:
            ip = ipaddress.IPv4Address(value)
        except ValueError:
            continue
        if not (ip.is_loopback or ip.is_unspecified or ip.is_multicast or ip.is_link_local) and value not in found:
            found.append(value)
    return found

class Handler(BaseHTTPRequestHandler):
    def serve(self, body):
        path = urlsplit(self.path).path
        if path == "/addresses.json":
            data = json.dumps({"app": "cndg-local-v3", "addresses": self.server.lan}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            if body:
                self.wfile.write(data)
            return
        if path not in FILES:
            self.send_error(404)
            return
        name, mime = FILES[path]
        try:
            with (HERE / name).open("rb") as file:
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(os.fstat(file.fileno()).st_size))
                self.send_header("Cache-Control", "no-cache")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                if body:
                    shutil.copyfileobj(file, self.wfile)
        except FileNotFoundError:
            self.send_error(404)
        except (BrokenPipeError, ConnectionResetError):
            pass
    def do_GET(self): self.serve(True)
    def do_HEAD(self): self.serve(False)
    def log_message(self, fmt, *args): pass

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--no-open", action="store_true")
    args = parser.parse_args()
    if not (HERE.parent / "综合刷题.html").is_file():
        sys.exit("请先完整解压刷题包，再运行启动文件。")
    try:
        server = ThreadingHTTPServer(("0.0.0.0", args.port), Handler)
    except OSError as e:
        sys.exit("启动失败。请先关闭之前的启动窗口，或使用 --port 更换端口。\n" + str(e))
    server.lan = addresses()
    port = server.server_address[1]
    local = "http://127.0.0.1:" + str(port)
    print("电脑打开二维码页  " + local + "/connect", flush=True)
    for ip in server.lan:
        print("手机同一 Wi-Fi  " + "http://" + ip + ":" + str(port) + "/mobile.html", flush=True)
    print("保持窗口打开。按 Ctrl+C 可停止。", flush=True)
    if not args.no_open:
        threading.Timer(0.3, functools.partial(webbrowser.open, local + "/connect")).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
