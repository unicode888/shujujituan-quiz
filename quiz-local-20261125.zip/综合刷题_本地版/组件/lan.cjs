// Read-only fallback for computers with Node.js and no Python 3.
const http = require('node:http'), fs = require('node:fs'), path = require('node:path');
const os = require('node:os'), cp = require('node:child_process');
const args = process.argv.slice(2);
const pos = args.indexOf('--port');
const port = pos < 0 ? 8787 : Number(args[pos+1]);
const files = new Map([
  ...['/', '/index.html', '/mobile.html'].map(p => [p, ['../综合刷题.html', 'text/html; charset=utf-8']]),
  ['/connect', ['connect.html', 'text/html; charset=utf-8']],
  ['/qr.js', ['qrcode.js','text/javascript; charset=utf-8']],
  ['/icon.png', ['icon.png', 'image/png']],
  ['/manifest.webmanifest', ['manifest.webmanifest','application/manifest+json']],
]);
if (!fs.existsSync(path.join(__dirname, '../综合刷题.html'))) { console.error('请完整解压刷题包。'); process.exit(1); }
let interfaces = {};
try { interfaces = os.networkInterfaces(); } catch { /* The connection page also accepts a manually entered address. */ }
const nets = Object.entries(interfaces).sort(([a],[b]) => Number(!/^en0$|wi-?fi|wlan/i.test(a)) - Number(!/^en0$|wi-?fi|wlan/i.test(b)));
const ips = [...new Set(nets.flatMap(([,v]) => (v || []).filter(n => (n.family==='IPv4' || n.family===4) && !n.internal && !n.address.startsWith('169.254.')).map(n=>n.address)))];
const server = http.createServer((req,res) => {
  const p = req.url.split('?')[0];
  if (!['GET','HEAD'].includes(req.method)) {res.writeHead(405).end(); return;}
  if (p==='/addresses.json') {res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'}).end(req.method==='HEAD' ? undefined : JSON.stringify({app:'cndg-local-v3',addresses:ips})); return;}
  if (!files.has(p)) {res.writeHead(404).end(); return;}
  const [name,mime] = files.get(p);
  const file = path.join(__dirname, name);
  fs.stat(file,(err,info) => {
    if (err) {res.writeHead(404).end(); return;}
    res.writeHead(200, {'Content-Type':mime,'Content-Length':info.size,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});
    if(req.method==='HEAD') {res.end(); return;}
    const stream=fs.createReadStream(file);
    stream.on('error',()=>res.destroy()); res.on('close',()=>stream.destroy()); stream.pipe(res);
  });
});
server.on('error',e=>{console.error('启动失败。请关闭之前的启动窗口，或使用 --port 更换端口。',e.message);process.exitCode=1;});
server.listen(port,'0.0.0.0',()=>{
  const n = server.address().port;
  const local = 'http://127.0.0.1:'+n+'/connect';
  console.log('电脑打开二维码页  '+local);
  ips.forEach(ip=>console.log('手机同一 Wi-Fi  http://'+ip+':'+n+'/mobile.html'));
  console.log('保持窗口打开。按 Ctrl+C 可停止。');
  if(args.includes('--no-open')) return;
  const cmd=process.platform==='darwin'?['open',local]:process.platform==='win32'?['rundll32.exe','url.dll,FileProtocolHandler',local]:['xdg-open',local];
  const child=cp.spawn(cmd[0],cmd.slice(1),{detached:true,stdio:'ignore'});child.on('error',()=>{});child.unref();
});
