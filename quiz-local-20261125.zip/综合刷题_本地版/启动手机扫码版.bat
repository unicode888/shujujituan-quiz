@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 -c "from http.server import ThreadingHTTPServer" >nul 2>nul
if not errorlevel 1 (
    py -3 "组件\lan.py" %*
    goto done
)
python -c "from http.server import ThreadingHTTPServer" >nul 2>nul
if not errorlevel 1 (
    python "组件\lan.py" %*
    goto done
)
where node >nul 2>nul
if not errorlevel 1 (
    node "组件\lan.cjs" %*
    goto done
)
echo 手机局域网模式需要 Python 3.7+ 或 Node.js 16+。电脑可直接双击「综合刷题.html」。
:done
pause
